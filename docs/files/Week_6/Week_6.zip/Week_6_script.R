# Week 6 script - PSYC121 labs

library(tidyverse) # always run this

# 6.3.1 - read in the data file:
# add your code here


# 6.3.2 - use glimpse, summary, and/or View to inspect the data
# add your code here


# 6.3.3 plot the estimated phone use as a boxplot
*MISSING_data_set_name* %>%
  ggplot(aes(x = *MISSING_DV*)) + # add the DV you want to plot
  geom_*MISSING* # what is the code/name for a ggplot boxplot?

# do this for the actual variable too


# 6.3.4 use the code above but plot as a density plot (geom_density)
# add your code here


# 6.3.5 plot the relationship between estimated phone use and actual phone use
*MISSING_data_set_name* %>%
ggplot(aes(x = *MISSING_DV1*, y = *MISSING_DV2*)) + # add the two DVs you want to plot
geom_point() # try varying the size and the alpha parameters (e.g., size = 3)

# 6.3.6 Use count to get see how many people overestimated compared to underestimated phone use

count(*MISSING_data_set_name*, accuracy)

# run a binomial test to see if the number of
# overestimations/underestimations would be expected by chance

binom.test()

# add the "UK_region" variable to the count to get a breakdown of the estimation accuracy by region

count(*MISSING_data_set_name*, UK_region, accuracy)
