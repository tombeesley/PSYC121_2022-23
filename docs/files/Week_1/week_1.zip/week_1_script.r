5+5

week_1_lecture_data <- c(7,8,8,7,3,1,6,9,3,8)

mean(week_1_lecture_data)

median(week_1_lecture_data)

getmode<-
  function(week_1_lecture_data) {
    uniqv<- unique(week_1_lecture_data)
    uniqv[which.max(tabulate(match(week_1_lecture_data, uniqv)))]
  }
getmode(week_1_lecture_data)

# Note: Any text that appears after the hash character is for you to read, it is ignored by R
# Note: So it is really useful to add comments to help explain what you are doing

# Use comment lines to explain what each of the above is doing

# Can you use what you have learned above to calculate central tendencty scores for dice rollking?

# This is code from David Howell's textbook, chapter 3 
NumCorrect <- c(54, 52, 51, 50, 36, 55, 44, 46, 57, 44, 43, 52, 38, 46,
                55, 34, 44, 39, 43, 36, 55, 57, 36, 46, 49, 46, 49, 47)
xbar <- mean(NumCorrect)
xbar.trim <- mean(NumCorrect, trim = .10)
med <- median(NumCorrect)

cat("The mean is = ", xbar,"\nThe 10% trimmed mean is ", xbar.trim, "\nThe median is = ", med)

hist(NumCorrect, main = "Number of Items Correct", breaks = 10, col = "green")

library(psych)
describe(NumCorrect)
