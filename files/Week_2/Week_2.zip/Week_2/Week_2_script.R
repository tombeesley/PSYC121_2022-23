library(tidyverse)

mean(penelope21$estimate)
sd(penelope21$estimate)

median(TRY CHANGE THIS TO GET THE MEDIAN ESTIMATE)

mean(penelope21$female_estimate, na.rm = TRUE )
mean(penelope21$other_estimate, na.rm = TRUE )

sd(penelope21$female_estimate, na.rm = TRUE)

hist(penelope21$estimate)

boxplot(penelope21$estimate)
boxplot(penelope21$female_estimate)
boxplot(penelope21$other_estimate)
boxplot(penelope21$estimate, notch=TRUE)

ggplot(penelope21, aes(x=identity, y=estimate),)+
geom_boxplot(fill="azure")+
theme_classic()

